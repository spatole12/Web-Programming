const postRecipe = require("./recipe");
module.exports = {


  recipe: postRecipe

};