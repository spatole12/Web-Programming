function IsArgArray(arr) {
    if (!Array.isArray(arr)) {
        throw `The entered array ${arr} is not an array`;
    }
}

function checkEachArgumentProvided(value, variable_name) {
    if (value == null) //!value
    {
        throw `Please provide the value of ${variable_name} as the value of ${variable_name} cannot be null`;
    }
}

function IsEachArgumentObject(obj1, obj2) {
    if (typeof (JSON.stringify(obj1)) !== "object") {
        throw `${JSON.stringify(obj1)} is not an object! 
        Please provide a valid object `;
    }
    if (typeof (JSON.stringify(obj2)) !== "object") {
        throw `${JSON.stringify(obj2)} is not an object! 
        Please provide a valid object `;
    }
}

function IsArgString(str) {
    if (typeof str !== "string") {
        throw `Please enter a feasible string as ${str} is not a string`;
    }
}



var flag = false;
let deepEquality = (obj1, obj2) => {
    checkEachArgumentProvided(JSON.stringify(obj1),"Object1");
    checkEachArgumentProvided(JSON.stringify(obj2),"Object2");
    let keys_1 = Object.keys(obj1).sort();
    let keys_2 = Object.keys(obj2).sort();
    
    if (keys_1.length == 0 && keys_2.length == 0)
        flag = true;
    else if (keys_1.length == keys_2.length) {
        for (var i = 0; i < keys_1.length; i++) {
            if (obj2.hasOwnProperty(keys_1[i])) {
                for (var j = 0; j < keys_2.length; j++) {
                    if (typeof (obj2[keys_1[i]]) !== "object" && typeof (obj1[keys_1[i]]) !== "object") {
                        if (obj2[keys_1[i]] == obj1[keys_1[i]]) {
                            flag = true;
                        } else {
                            return false;
                        }
                    } else {
                        flag = deepEquality(obj2[keys_2[j]], obj1[keys_1[i]]);
                    }
                }
            } else {
                flag = false;
                break;
            }
        }
        return flag;
    } else {
        return false;
    }
}

let uniqueElements = (arr) => {
    checkEachArgumentProvided(arr,"Array");
    IsArgArray(arr); 
    const l_unique_elements = [...new Set(arr)];
    let no_of_unique_ele = l_unique_elements.length;
    return no_of_unique_ele;

}

let countOfEachCharacterInString = (str) => {
    checkEachArgumentProvided(str,"String");
    IsArgString(str);
    let charMap = new Object();
    let char_array = [...str];
    const l_unique_elements = [...new Set(char_array)];

    l_unique_elements.forEach(element => {
        var count = 0;
        char_array.forEach(ele => {
            if (ele == element) {
                count++;
            }
        });
        charMap[element] = count;
    });
    return charMap;
}


module.exports = {
    deepEquality,
    uniqueElements,
    countOfEachCharacterInString
}