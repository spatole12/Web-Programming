const geom = require("./geometry");
const utility = require("./utilities");

let volume_prism = null;
let surface_area = null;
let volumeOfSphere =null;
let surface_area_s =null; 
let deepEquality = null;
let unique_elements =null;
let charMap = null;

try{
volume_prism = geom.volumeOfRectangularPrism(6,5,4);
console.log(volume_prism);

volume_prism = geom.volumeOfRectangularPrism(3,4,9);
console.log(volume_prism);

volume_prism = geom.volumeOfRectangularPrism(7,4,7);
console.log(volume_prism);

volume_prism = geom.volumeOfRectangularPrism(4,8,3);
console.log(volume_prism);

volume_prism = geom.volumeOfRectangularPrism(9,3,6);
console.log(volume_prism);
}
catch(error)
{console.log(error)}

try{
surface_area = geom.surfaceAreaOfRectangularPrism(2,3,4);
console.log(surface_area);

surface_area = geom.surfaceAreaOfRectangularPrism(5,9,4);
console.log(surface_area);

surface_area = geom.surfaceAreaOfRectangularPrism(1,3,9);
console.log(surface_area);

surface_area = geom.surfaceAreaOfRectangularPrism(7,3,4);
console.log(surface_area);

surface_area = geom.surfaceAreaOfRectangularPrism(3,6,4);
console.log(surface_area);
}
catch(error)
{console.log(error)}

try{
volume_sphere = geom.volumeOfSphere(6);
console.log(volume_sphere);

volume_sphere = geom.volumeOfSphere(5);
console.log(volume_sphere);

volume_sphere = geom.volumeOfSphere(7);
console.log(volume_sphere);

volume_sphere = geom.volumeOfSphere(3);
console.log(volume_sphere);

volume_sphere = geom.volumeOfSphere(8);
console.log(volume_sphere);
}
catch(error)
{console.log(error)}

try{
surface_area_s = geom.surfaceAreaOfSphere(9);
console.log(surface_area_s); 

surface_area_s = geom.surfaceAreaOfSphere(3);
console.log(surface_area_s); 

surface_area_s = geom.surfaceAreaOfSphere(5);
console.log(surface_area_s); 

surface_area_s = geom.surfaceAreaOfSphere(8);
console.log(surface_area_s); 

surface_area_s = geom.surfaceAreaOfSphere(2);
console.log(surface_area_s); 
}
catch(error)
{console.log(error)}

try{
deepEquality = utility.deepEquality({a:2,b:{c:4,d:5}},{b:{c:4,d:5},a:2});
console.log(deepEquality);

deepEquality = utility.deepEquality({a:2,b:{c:4,d:5}},{b:{c:4,d:5},a:3});
console.log(deepEquality);

deepEquality = utility.deepEquality({a:2,b:{c:4,d:5,e:6}},{b:{c:4,d:5},a:2});
console.log(deepEquality);

deepEquality = utility.deepEquality({a:2,b:{c:4,d:5,e:5}},{b:{c:4,d:5,e:5},a:2});
console.log(deepEquality);

deepEquality = utility.deepEquality({a:2,b:{c:4}},{b:{c:4,d:5},a:2});
console.log(deepEquality);
}
catch(error)
{console.log(error)}

try{
unique_elements = utility.uniqueElements(["a", "a", "b", "a", "b", "c","d","d"]);
console.log(unique_elements);

unique_elements = utility.uniqueElements(["a", "a", "b", "a", "b", "c","k","r","d","d"]);
console.log(unique_elements);

unique_elements = utility.uniqueElements(["a", "a", "v", "a", "b", "c","d","d","d"]);
console.log(unique_elements);

unique_elements = utility.uniqueElements(["a", "b", "b", "a", "b", "c","d","d","f","f","l"]);
console.log(unique_elements);

unique_elements = utility.uniqueElements(["j", "a", "b", "a", "b", "c","d","d","s"]);
console.log(unique_elements);
}
catch(error)
{console.log(error)}

try{
charMap = utility.countOfEachCharacterInString("Hello, the pie is in the oven");
console.log(charMap);

charMap = utility.countOfEachCharacterInString("Hello, shivani here");
console.log(charMap);

charMap = utility.countOfEachCharacterInString("How is it going");
console.log(charMap);

charMap = utility.countOfEachCharacterInString("It is quite cloudy today");
console.log(charMap);

charMap = utility.countOfEachCharacterInString("It is a great day");
console.log(charMap);
}
catch(error)
{console.log(error)}