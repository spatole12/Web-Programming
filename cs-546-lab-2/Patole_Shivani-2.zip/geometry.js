function checkEachArgumentProvided(value, variable_name){
    if (value == null) //!value
    {
        throw `Please provide the value of ${variable_name} as the value of ${variable_name} cannot be null`;
    }
}

function checkIsANumber (value, variable_name){
    //Nan
    //value == undefined || 
    if (typeof value !== "number") {
        throw `Please enter a feasible number as ${variable_name} is not a number`;
    }
}

function checkWithinProperBounds(value, variable_name){
    if (value < 1) {
        throw `${variable_name} is not within bounds.Please enter a non-zero positive number`;
    }

}

module.exports= {
    volumeOfRectangularPrism: (length, width, height) => {
        let par_obj = new Object();
        par_obj['Length'] = length;
        par_obj['Width'] =  width;
        par_obj['Height'] = height;
        let keys = Object.keys(par_obj);
        for (var i=0 ; i<keys.length ; i++)
        {
            checkEachArgumentProvided(par_obj[keys[i]],keys[i]);
            checkIsANumber(par_obj[keys[i]],keys[i]);
            checkWithinProperBounds(par_obj[keys[i]],keys[i]);
        }

        let l_volume = length * width * height;
        return l_volume;
    },

    surfaceAreaOfRectangularPrism: (length, width, height) => {
       let par_obj_sur = new Object();
       par_obj_sur['Length'] = length;
       par_obj_sur['Width'] =  width;
       par_obj_sur['Height'] = height;
       //console.log(par_obj_sur);
        let keys_sur = Object.keys(par_obj_sur);
        for (let i=0 ; i<keys_sur.length ; i++)
        {
            checkEachArgumentProvided(par_obj_sur[keys_sur[i]],keys_sur[i]);
            checkIsANumber(par_obj_sur[keys_sur[i]],keys_sur[i]);
            checkWithinProperBounds(par_obj_sur[keys_sur[i]],keys_sur[i]);
        }
        let l_surface_area = 2*(width * length + height * length + height * width);
        return l_surface_area;
    },

    volumeOfSphere: (radius) => {
        checkEachArgumentProvided(radius, "Radius");
        checkIsANumber(radius, "Radius");
        checkWithinProperBounds(radius, "Radius");
        let l_volume_of_sphere = (4 / 3) * (Math.PI) * (Math.pow(radius,3));
        return l_volume_of_sphere;
    },

    surfaceAreaOfSphere: (radius) => {
        checkEachArgumentProvided(radius, "Radius");
        checkIsANumber(radius, "Radius");
        checkWithinProperBounds(radius, "Radius");
        let l_surface_area_of_sphere = 4 * (Math.PI) * Math.pow(radius,2);
        return l_surface_area_of_sphere;
    } 
};